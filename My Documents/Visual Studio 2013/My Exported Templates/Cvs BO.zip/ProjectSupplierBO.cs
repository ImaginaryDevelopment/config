﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CVS.Common;
using CVS.DataAccess.Entities.Project;
using CVS.DataAccess.Managers.Project;
using OceansideTen.Common;

namespace CVS.DataAccess.BusinessObjects
{
    public class $safeitemname$ : BusinessObject<$safeitemname$>
    {
        /*
        public void Save(int projectId, IReadOnlyList<int> projectSupplierOrgIds, SqlConnection conn, SqlTransaction trans)
        {
            ProjectSupplierManager psm = new ProjectSupplierManager();
            psm.UpdateProjectOrgsByProjectId(projectId, projectSupplierOrgIds, conn, trans);
        }

        public List<int> GetByProjectId(int projectId)
        {
            using (SqlConnection conn = new SqlConnection(base.ConnectionString))
            {
                conn.Open();
                return GetByProjectId(projectId, conn, null);
            }
        }

        public List<int> GetByProjectId(int projectId, SqlConnection conn, SqlTransaction trans)
        {
            List<int> orgs = new List<int>();

            List<ProjectSupplier> pOrgs = new ProjectSupplierManager().GetByProjectId(projectId, conn, trans);
            if (pOrgs != null && pOrgs.Count > 0)
            {
                orgs = (from po in pOrgs select po.OrgId).Distinct().ToList();
            }

            return orgs;
        }
        */
    }
}
